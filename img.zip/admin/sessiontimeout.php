<?php
    $time  = $_SERVER['REQUEST_TIME'];

    $timeDuration = 3600;

    if (isset($_SESSION['LAST_ACTIVITY']) && ($time - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
        session_unset();
        session_destroy();
        session_start();
        $_SESSION['sessionexpnotifacation'] = "<script type=\"text/javascript\">alert(\"Session Expired\");</script>\n";
    }
    $_SESSION['LAST_ACTIVITY'] = $time;
?>
